package sample;

public class ViewGradeController {
}
