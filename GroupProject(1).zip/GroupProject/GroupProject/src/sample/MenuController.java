package sample;

public class MenuController {
}
