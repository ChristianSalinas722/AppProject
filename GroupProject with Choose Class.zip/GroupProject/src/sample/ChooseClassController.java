package sample;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;

public class ChooseClassController {

    @FXML
    private ListView<?> list;

}
